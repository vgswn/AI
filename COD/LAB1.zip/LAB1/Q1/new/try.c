#include <stdio.h>
int main(int argc, char const *argv[]) {
	int z;
	int q=5;
	int _ao09;
	int 103;
	unsigned int x=1000.68;
	unsigned int y=13.08e-80.20;
	unsigned int z=133e80;
	return 0;
}