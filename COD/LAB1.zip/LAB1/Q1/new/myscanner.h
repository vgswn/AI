#define IDENTIFIER 1
#define NUMBER 2
#define KEYWORD 3
#define OTHER 4
#define NEWLINE 5
#define CONTROL_SMT 6