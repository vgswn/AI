#include <stdio.h>
int main(int argc, char const *argv[]) {
	int z;
	int q=5;
	int _ao09;
	int 103;
	return 0;
}